const nav = document.querySelector('.nav-links');
const toggle = document.querySelector('.menu-toggle');
const links = [...document.querySelectorAll('.nav-link')];

toggle?.addEventListener('click', () => nav.classList.toggle('open'));
links.forEach(link => link.addEventListener('click', () => nav.classList.remove('open')));

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

const sections = [...document.querySelectorAll('section[id]')];
const navObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    links.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`));
  });
}, { rootMargin: '-40% 0px -52% 0px', threshold: 0 });
sections.forEach(section => navObserver.observe(section));
